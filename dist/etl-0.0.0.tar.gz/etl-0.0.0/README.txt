tools
    pytest
        testing tool
    tox
        run test suite in multiple environments
        tox will throw 'ERROR: InvocationError:' if there are no tests available
